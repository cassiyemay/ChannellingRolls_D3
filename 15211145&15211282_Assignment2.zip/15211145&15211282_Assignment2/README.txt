Team:
15211282 Zeng Chen
15211145 Lan Wei

Extra Feature:
The extract feature we added showed that each region had the population in each year. In default year was 2016. 
When click the different year, the population per region would change. 
When played the start button, the population per region would automatically changed.
It was animated.

Because different regions have different color which showed in the bubble chart, using the bar chart could be more clear to see the relationship with the growth of the region and the increasing of the GDP for same region(with same color) as the time went by combine with the bubble chart.

In addition, in the Part 1 bubble chart, when mouseover the bubble chart the country names and some details of the country could be found.
When selected the different country from the drop down menu, it would show the the journey of a country to be seen as a trace of positions in the scatter plot.